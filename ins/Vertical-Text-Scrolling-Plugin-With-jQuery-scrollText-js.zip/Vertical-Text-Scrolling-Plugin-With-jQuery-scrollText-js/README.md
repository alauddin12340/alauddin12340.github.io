## jQuery.scrollText.js


### usage

```js
$(function(){
    $(".container").scrollText({
        'duration': 2000
    });
});
```

## demo

[https://rawgit.com/FrankFan/jQuery.scrollText.js/master/index.html](https://rawgit.com/FrankFan/jQuery.scrollText.js/master/index.html)

