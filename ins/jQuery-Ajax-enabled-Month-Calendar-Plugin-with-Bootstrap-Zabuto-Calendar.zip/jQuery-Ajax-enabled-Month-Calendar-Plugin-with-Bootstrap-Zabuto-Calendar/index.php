<?php

header('Location: examples/index.html');
